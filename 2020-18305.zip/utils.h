#ifndef UTILS_H
#define UTILS_H

#include <string>

using namespace std;

unsigned int StringToInt(string s);

#endif